const navItems = [
  ["index.html","Home","ہوم"],["about.html","About Us","ہمارے بارے میں"],["admission.html","Admission","داخلہ"],["result.html","Results","نتائج"],["student-portal.html","Student Portal","طلبہ پورٹل"],["faqs.html","FAQs","سوالات"]
];
const path = location.pathname.split("/").pop() || "index.html";
const header = document.getElementById("site-header");
if(header){
  header.innerHTML = `<header class="site-header"><div class="nav-wrap"><a class="brand" href="index.html"><span class="brand-mark">CEA</span><span class="brand-text">Chakesar Education Academy<span>چکیسر ایجوکیشن اکیڈمی</span></span></a><button class="menu-btn" id="menu-btn" aria-label="Open navigation">☰</button><nav id="main-nav">${navItems.map(([href,en,ur])=>`<a href="${href}" class="${path===href?'active':''}" data-en="${en}" data-ur="${ur}">${en}</a>`).join("")}<a href="login.html" data-en="Login" data-ur="لاگ اِن">Login</a></nav><button class="lang-btn" id="language-toggle" type="button">اردو</button></div></header>`;
}
const footer = document.getElementById("site-footer");
if(footer){
 footer.innerHTML = `<footer class="site-footer"><div class="footer-inner"><div><strong>Chakesar Education Academy High School Danakool</strong><div lang="ur" dir="rtl">چکیسر ایجوکیشن اکیڈمی ہائی سکول داناکول</div><p data-en="Danakool, Chakesar, Shangla" data-ur="داناکول، چکیسر، شانگلہ">Danakool, Chakesar, Shangla</p></div><div class="footer-links"><a href="about.html" data-en="About Us" data-ur="ہمارے بارے میں">About Us</a><a href="admission.html" data-en="Admissions" data-ur="داخلے">Admissions</a><a href="result.html" data-en="Results" data-ur="نتائج">Results</a><a href="faqs.html" data-en="FAQs" data-ur="سوالات">FAQs</a></div></div><div class="copyright">© <span id="year"></span> Chakesar Education Academy. All rights reserved.</div></footer>`;
}
function setLanguage(lang){
 document.documentElement.lang = lang;
 document.body.classList.toggle("urdu",lang==="ur");
 document.querySelectorAll("[data-en][data-ur]").forEach(el=>{el.textContent=el.dataset[lang];});
 const toggle=document.getElementById("language-toggle");
 if(toggle) toggle.textContent=lang==="en"?"اردو":"English";
 try{localStorage.setItem("cea-language",lang)}catch(e){}
}
let saved="en";try{saved=localStorage.getItem("cea-language")||"en"}catch(e){}
setLanguage(saved);
document.getElementById("language-toggle")?.addEventListener("click",()=>setLanguage(document.documentElement.lang==="en"?"ur":"en"));
document.getElementById("menu-btn")?.addEventListener("click",()=>document.getElementById("main-nav").classList.toggle("open"));
const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
document.getElementById("admission-form")?.addEventListener("submit",e=>{e.preventDefault();const msg=document.getElementById("form-message");msg.textContent=document.documentElement.lang==="ur"?"فارم کا ڈیمو مکمل ہوا۔ حقیقی درخواست جمع نہیں ہوئی۔ براہ کرم سکول آفس سے رابطہ کریں۔":"Demo completed. No real application was sent. Please contact the school office.";});
document.getElementById("result-form")?.addEventListener("submit",e=>{e.preventDefault();const msg=document.getElementById("result-message");msg.textContent=document.documentElement.lang==="ur"?"نتائج کا ڈیٹا بیس ابھی منسلک نہیں ہے۔ براہ کرم سکول آفس سے رابطہ کریں۔":"The results database is not connected yet. Please contact the school office.";});
document.getElementById("account-form")?.addEventListener("submit",e=>{e.preventDefault();const msg=document.getElementById("form-message");msg.textContent=document.documentElement.lang==="ur"?"اکاؤنٹ سسٹم ابھی منسلک نہیں ہے۔":"Account system is not connected yet.";});
