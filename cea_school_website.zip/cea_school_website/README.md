# Chakesar Education Academy High School Danakool

A responsive static website for GitHub Pages with an English / Urdu language switch.

## Pages
- Home (`index.html`)
- About Us (`about.html`)
- Admission (`admission.html`)
- Results (`result.html`)
- Student Portal (`student-portal.html`)
- Login (`login.html`)
- Sign Up (`signup.html`)
- FAQs (`faqs.html`)

## Publish on GitHub Pages
1. Create a public repository named `cea` under `malakaimal`.
2. Upload all files and folders from this ZIP to the repository root. Do not upload the ZIP file alone.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then Save.
6. Your website address should be: https://malakaimal.github.io/cea/

## Important
The admission form, results lookup, login and student portal are front-end previews only. They do not store real student information or authenticate users. Connect a secure backend (for example Supabase with Row Level Security, or a server-side Google Apps Script endpoint) before collecting real student data. Never put secret API keys in browser JavaScript.
